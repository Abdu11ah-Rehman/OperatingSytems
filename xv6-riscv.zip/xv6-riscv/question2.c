#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main() {
    int p[2];
    pipe(p);

    if (fork() == 0) {
        close(1);
        dup(p[1]);
        close(p[0]);
        close(p[1]);
        char *args[] = { "ls", "-al", "/", 0 };
        exec("/bin/ls", args);
        exit(0);
    } else if (fork() == 0) {
        close(0);
        dup(p[0]);
        close(p[1]);
        close(p[0]);
        char *args[] = { "tr", "a-z", "A-Z", 0 };
        exec("/usr/bin/tr", args);
        exit(0);
    } else {
        close(p[0]);
        close(p[1]);
        wait(0);
        wait(0);
    }

    exit(0);
}
