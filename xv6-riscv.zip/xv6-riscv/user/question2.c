#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main() {
    int p[2];
    pipe(p); // Create a pipe

    if (fork() == 0) {
        // First child process: ls -al /
        close(1);        // Close stdout
        dup(p[1]);       // Replace stdout with pipe write end
        close(p[0]);     // Close unused read end of pipe
        close(p[1]);     // Close the write end after duplicating
        char *args[] = { "ls", "-al", "/", 0 }; // Arguments for ls
        exec("/bin/ls", args); // Execute ls
        exit(0);
    } else if (fork() == 0) {
        // Second child process: tr a-z A-Z
        close(0);        // Close stdin
        dup(p[0]);       // Replace stdin with pipe read end
        close(p[1]);     // Close unused write end of pipe
        close(p[0]);     // Close the read end after duplicating
        char *args[] = { "tr", "a-z", "A-Z", 0 }; // Arguments for tr
        exec("/usr/bin/tr", args); // Execute tr
        exit(0);
    } else {
        // Parent process
        close(p[0]); // Close both ends of the pipe
        close(p[1]);
        wait(0);     // Wait for children to finish
        wait(0);
    }

    exit(0);
}
