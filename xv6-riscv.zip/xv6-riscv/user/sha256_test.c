#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: sha256_test <message>\n");
        exit(1);
    }

    const char *message = argv[1];
    int len = strlen(message);

    uint8_t hash[32];

    // Call the SHA-256 system call
    if (sha256((uint64)message, len, (uint64)hash) < 0) {
        printf("System call failed.\n");
        exit(1);
    }

    printf("SHA-256 hash: ");
    for (int i = 0; i < 32; i++)
        printf("%02x", hash[i]);
    printf("\n");

    exit(0);
}
